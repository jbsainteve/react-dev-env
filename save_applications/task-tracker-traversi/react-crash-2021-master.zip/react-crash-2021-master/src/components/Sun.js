import React from 'react'

const Sun = () => {
  return (
    <div className='background-fullviewport'>

          <div className="sun">

      </div>
    </div>
  )
}

export default Sun