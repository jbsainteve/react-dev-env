import React from 'react'
import image from '../imgs/IMG_7848.PNG'

const Rplanet = () => {
  return (
    <div className='centered'>
        <div className="palnet">
            <img src={image} alt="" className='image' />
        </div>
    </div>
  )
}

export default Rplanet