import React from 'react'

const Moon = () => {
  return (
    <div className='centered'>
        <div className="moon">
            <ul>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
            </ul>
        </div>
    </div>
  )
}

export default Moon